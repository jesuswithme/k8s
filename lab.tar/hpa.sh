#!/bin/bash
while true 
do 
curl 10.110.133.33 
done
